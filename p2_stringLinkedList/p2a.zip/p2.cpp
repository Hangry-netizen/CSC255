/*
* Jospeh Song
* Queena Lee
* CSC255 Spring 2023
* Assignment: Program 2a
*/

#include <iostream>
#include <fstream>

#include "p2.h"

using namespace std;

//******************************************************************************
//P2b
int stringLinkedList::getIndex(std::string text, node *pn, int index) const {
    //recursion helper
    return true;
}

//******************************************************************************

void stringLinkedList::printIt(node *pn, int index) const {
    if ((!(index < 0)) && index < listCount) {
        //if index exist within listCount range
        //print list and recurse function until the end of the list
        cout << index << " " << pn -> text << endl;

        printIt(pn -> next, index + 1);
    }
}

//******************************************************************************

void stringLinkedList::clear(node *pn) {
    //delete first node and set the on its right to first
    delete first;
    first = pn;
}

//******************************************************************************

stringLinkedList::stringLinkedList() {
    //initialize first, last, and listCount
    first = last = NULL;
    listCount = 0;
}

//******************************************************************************

stringLinkedList::~stringLinkedList() {
    node *nextNode = first -> next;

    while (first) {
        //while a node exist at the beginning of the list
        //delete the node and move right to the next entry on the list
        delete first;

        if (nextNode) {
            first = nextNode;
            nextNode = first -> next;
        }
    }
}

//******************************************************************************

bool stringLinkedList::insert(std::string text) {
    //create new node pointing to the value of first
    node *newNode = new node(text, first);

    //if there is no existing list, set newNode as last
    if (!listCount) {
        last = newNode;
    }

    //set newNode as first entry and increment listCount
    first = newNode;
    listCount++;

    return true;
}

//******************************************************************************

bool stringLinkedList::add(std::string text) {    
    //create new node pointing to null
    node *newNode = new node(text);

    //if there is an existing list
    //set the pointer of the last node to the newNode
    //otherwise, set newNode as first entry as well
    if (last) {
        last -> next = newNode;
    } else {
        first = newNode;
    }
    
    //set newNode as last entry and increment listCount
    last = newNode;
    listCount++;

    return true;
}

//******************************************************************************

bool stringLinkedList::insertAt(int index, std::string text) {
    //determine if index is withtin listCount range (0 <= index <= listCount)
    bool rc = !((index < 0) || (index > listCount));

    if (rc) {
        if (index == 0) {
            //if index is 0, insert newNode at the beginning of the list
            node *newNode = new node(text, first);
            first = newNode;
            
        } else {
            //if index is within listCount range and larger than 0
            //get to the given index
            node *pointer = first;
            int count = 1;
            
            while (count < index) {
                pointer = pointer -> next;
                count++;
            }
    
            //at the index location, create newNode
            //have the newNode pointing to the node to its right
            //and the previous node pointing to newNode
            node *newNode = new node(text, pointer->next);
            pointer -> next = newNode;
        }
    
        listCount++;
    }

    return rc;
}

//******************************************************************************
//P2b
bool stringLinkedList::deleteAt(int index, std::string &text) {
    //deletes the entry at the given index
    //returns true if if the index was within 0 <= index < length()
    //returns false otherwise
    //if delete takes place, it returns the string in the deleted node via "text"
    text = "dubbed";
    return true;
}

//******************************************************************************
//P2b
bool stringLinkedList::readAt(int index, std::string &text) const {
    //same as deleteAt(), but does not delete the entry
    text = "dubbed";
    return true;
}

//******************************************************************************

void stringLinkedList::clear() { 
    node *pn = first -> next;

    if (first) {
        //if there exist any nodes
        //clear the first node, and set first to the node on its right
        //recurse function until list is clear 
        clear(pn);
        clear();
    }

    listCount = 0;
}

//******************************************************************************
//P2b
int stringLinkedList::getIndex(std::string text) const{
    //returns the first position at which the value v was found
    //otherwise, returns -1
    //this much be implemented with recursion, not a loop
    return true;
}

//******************************************************************************

void stringLinkedList::printIt() const {
    //if list exist, print list starting from the first node
    if (first) {
        printIt(first, 0);
    }
}

//******************************************************************************

int stringLinkedList::count() const {
    //returns the number of entries in the list, listCount
    return listCount;
}